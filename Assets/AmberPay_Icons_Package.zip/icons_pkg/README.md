# AmberPay quick-action icons

The four icons used in the Home screen quick-actions row: Send, Add money,
Request, Pay bill.

## /svg
Vector masters — the source of truth, edit these not the PNGs.
- `<name>.svg` — stroke set to `currentColor`. Use this in code (React/Vue/
  plain HTML) so the icon inherits whatever color you set via CSS
  (`color: var(--navy)` etc.) — this is the one you actually want in an app.
- `<name>-navy.svg` — fixed navy (#101B33), for static use (docs, exports).
- `<name>-white.svg` — fixed white, for dark or photo backgrounds.
- `<name>-tile.svg` — the icon already set in the 56×56 rounded-square button
  tile exactly as it appears in the prototype's quick-actions row (white
  tile, hairline border, navy icon) — drop-in ready, no assembly needed.

All are on a 24×24 viewBox (56×56 for the tile), stroke-width 1.7, round caps/
joins — keep these consistent if you add more icons to the same set later.

## /png
Rasterized exports of the plain icon at 24 / 32 / 48 / 64 / 128 / 256px, in
both navy and white.

## /png_tile
The tile (button) version pre-rendered at 112px and 224px (2x/4x of the 56pt
base, for standard and Retina use).
